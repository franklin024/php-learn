<?php $__env->startSection('content'); ?>
    
    <div class="max-w-2xl mx-auto mt-6 p-4">

        
        <div class="mb-6">
            <a href="<?php echo e(route('task.index')); ?>"
                class="inline-flex items-center gap-1 font-medium text-slate-600 hover:text-slate-900 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                    class="size-4">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
                </svg>
                Quay lại danh sách
            </a>
        </div>

        
        <div class="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden p-6 sm:p-8">

            <h2 class="text-2xl font-bold text-slate-800 mb-6 text-center">
                <?php echo e(isset($task) ? 'Chỉnh Sửa Công Việc' : 'Tạo Công Việc Mới'); ?>

            </h2>

            <form method="POST"
                action="<?php echo e(isset($task) ? route('task.update', ['task' => $task]) : route('task.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php if(isset($task)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>

                
                <div class="mb-6">
                    <label for="title" class="block text-sm font-semibold text-slate-700 mb-2">Tiêu đề</label>
                    <input type="text" name="title" id="title" 
                        value="<?php echo e(old('title', $task->title ?? null)); ?>"  class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'w-full rounded-md border px-3 py-2 text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-1 transition duration-150 ease-in-out',
                            'border-red-500 focus:ring-red-500' => $errors->has('title'),
                            'border-slate-300 focus:border-slate-400 focus:ring-slate-400' => !$errors->has(
                                'title'),
                        ]); ?>">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-500 flex items-center gap-1">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="size-4">
                                <path fill-rule="evenodd"
                                    d="M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0Zm-8-5a.75.75 0 0 1 .75.75v4.5a.75.75 0 0 1-1.5 0v-4.5A.75.75 0 0 1 10 5Zm0 10a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"
                                    clip-rule="evenodd" />
                            </svg>
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="mb-6">
                    <label for="description" class="block text-sm font-semibold text-slate-700 mb-2">Mô tả ngắn</label>
                    <textarea name="description" id="description" rows="3" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'w-full rounded-md border px-3 py-2 text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-1 transition duration-150 ease-in-out resize-none',
                        'border-red-500 focus:ring-red-500' => $errors->has('description'),
                        'border-slate-300 focus:border-slate-400 focus:ring-slate-400' => !$errors->has(
                            'description'),
                    ]); ?>"><?php echo e(old('description', $task->description ?? null)); ?></textarea>

                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-500 flex items-center gap-1">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="size-4">
                                <path fill-rule="evenodd"
                                    d="M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0Zm-8-5a.75.75 0 0 1 .75.75v4.5a.75.75 0 0 1-1.5 0v-4.5A.75.75 0 0 1 10 5Zm0 10a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"
                                    clip-rule="evenodd" />
                            </svg>
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="mb-8">
                    <label for="long_description" class="block text-sm font-semibold text-slate-700 mb-2">Chi tiết (Tùy
                        chọn)</label>
                    <textarea name="long_description" id="long_description" rows="7" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'w-full rounded-md border px-3 py-2 text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-1 transition duration-150 ease-in-out',
                        'border-red-500 focus:ring-red-500' => $errors->has('long_description'),
                        'border-slate-300 focus:border-slate-400 focus:ring-slate-400' => !$errors->has(
                            'long_description'),
                    ]); ?>"><?php echo e(old('long_description', $task->long_description ?? null)); ?></textarea>

                    <?php $__errorArgs = ['long_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-500 flex items-center gap-1">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="size-4">
                                <path fill-rule="evenodd"
                                    d="M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0Zm-8-5a.75.75 0 0 1 .75.75v4.5a.75.75 0 0 1-1.5 0v-4.5A.75.75 0 0 1 10 5Zm0 10a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"
                                    clip-rule="evenodd" />
                            </svg>
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="flex items-center gap-4">
                    <button type="submit"
                        class="w-full rounded-md bg-slate-800 px-4 py-2.5 text-center text-sm font-semibold text-white shadow-sm hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:ring-offset-2 transition-all">
                        <?php if(isset($task)): ?>
                            Cập nhật
                        <?php else: ?>
                            Tạo mới
                        <?php endif; ?>
                    </button>

                    <a href="<?php echo e(route('task.index')); ?>"
                        class="w-full rounded-md bg-white border border-slate-300 px-4 py-2.5 text-center text-sm font-semibold text-slate-700 shadow-sm hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-200 focus:ring-offset-2 transition-all">
                        Hủy bỏ
                    </a>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\kai\Desktop\php_sub\task-list\resources\views/form.blade.php ENDPATH**/ ?>