<?php $__env->startSection('content'); ?>
    <div class="min-h-screen flex items-center justify-center px-4">

        
        <div class="w-full max-w-lg bg-white p-8 rounded-lg border border-slate-200 shadow-md">

            <h1 class="text-2xl font-bold text-center text-slate-800 mb-6">Đăng Nhập</h1>

            <form method="POST" action="<?php echo e(route('login.store')); ?>">
                <?php echo csrf_field(); ?>

                
                <div class="mb-4">
                    <label for="email" class="block text-sm font-medium text-slate-700 mb-1">Địa chỉ Email</label>
                    <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>"
                        class="w-full border-slate-300 rounded-md shadow-sm p-2 border focus:ring-blue-500 focus:border-blue-500"
                        placeholder="admin@example.com" required autofocus>

                    
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="mb-6">
                    <label for="password" class="block text-sm font-medium text-slate-700 mb-1">Mật khẩu</label>
                    <input type="password" name="password" id="password"
                        class="w-full border-slate-300 rounded-md shadow-sm p-2 border focus:ring-blue-500 focus:border-blue-500"
                        placeholder="******" required>

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <button type="submit"
                    class="w-full bg-slate-800 text-white font-bold py-2.5 px-4 rounded-md hover:bg-slate-700 transition duration-150">
                    Đăng Nhập
                </button>

            </form>

            
            <div class="mt-6 text-center border-t border-slate-100 pt-4">
                <p class="text-sm text-slate-600">
                    Chưa có tài khoản?
                    <a href="<?php echo e(route('register')); ?>" class="font-medium text-blue-600 hover:text-blue-500 hover:underline">
                        Đăng ký ngay
                    </a>
                </p>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\kai\Desktop\php_sub\task-list\resources\views/auth/login.blade.php ENDPATH**/ ?>