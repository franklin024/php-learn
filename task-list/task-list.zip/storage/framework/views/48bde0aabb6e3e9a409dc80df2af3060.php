<?php echo e($slot); ?>

<?php /**PATH C:\Users\kai\Desktop\php_sub\task-list\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>