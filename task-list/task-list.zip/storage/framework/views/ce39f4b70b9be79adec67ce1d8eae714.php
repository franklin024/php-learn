<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\kai\Desktop\php_sub\task-list\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>