<?php $__env->startSection('content'); ?>
    <div class="min-h-screen flex items-center justify-center px-4">


        <div class="w-full max-w-lg bg-white p-8 rounded-lg border border-slate-200 shadow-md">
            <h1 class="text-2xl font-bold text-center mb-6 text-slate-700">Đăng Ký Tài Khoản</h1>

            <form method="POST" action="<?php echo e(route('register.store')); ?>">
                <?php echo csrf_field(); ?>

                
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-slate-700 mb-1">Họ và Tên</label>
                    <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>"
                        class="w-full border border-slate-300 rounded px-3 py-2 focus:outline-none focus:border-blue-500"
                        placeholder="Nhập tên của bạn">

                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="mb-4">
                    <label for="email" class="block text-sm font-medium text-slate-700 mb-1">Email</label>
                    <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>"
                        class="w-full border border-slate-300 rounded px-3 py-2 focus:outline-none focus:border-blue-500"
                        placeholder="email@example.com">

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="mb-4">
                    <label for="password" class="block text-sm font-medium text-slate-700 mb-1">Mật khẩu</label>
                    <input type="password" name="password" id="password"
                        class="w-full border border-slate-300 rounded px-3 py-2 focus:outline-none focus:border-blue-500"
                        placeholder="******">

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="mb-6">
                    <label for="password_confirmation" class="block text-sm font-medium text-slate-700 mb-1">Xác nhận mật
                        khẩu</label>
                    <input type="password" name="password_confirmation" id="password_confirmation"
                        class="w-full border border-slate-300 rounded px-3 py-2 focus:outline-none focus:border-blue-500"
                        placeholder="Nhập lại mật khẩu y hệt bên trên">
                </div>

                
                <button type="submit"
                    class="w-full bg-blue-600 text-white font-bold py-2 px-4 rounded hover:bg-blue-700 transition duration-200">
                    Đăng Ký Ngay
                </button>

                
                <div class="mt-4 text-center text-sm">
                    <span class="text-slate-600">Đã có tài khoản?</span>
                    <a href="<?php echo e(route('login')); ?>" class="text-blue-600 hover:underline">Đăng nhập</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\kai\Desktop\php_sub\task-list\resources\views/auth/register.blade.php ENDPATH**/ ?>