<!DOCTYPE html>
<html>

<head>
    <title>Nhắc nhở công việc</title>
</head>

<body style="font-family: Arial, sans-serif; color: #333;">
    <h2>Chào <?php echo e($user->name); ?>,</h2>

    <p>Hôm nay bạn vẫn còn <strong><?php echo e($tasks->count()); ?></strong> công việc chưa hoàn thành:</p>

    <ul>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li style="margin-bottom: 5px;">
                <strong><?php echo e($task->title); ?></strong>
                <br>
                <span style="color: #666; font-size: 12px;"><?php echo e($task->description); ?></span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <p>
        <a href="<?php echo e(route('task.index')); ?>"
            style="background: #2563eb; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
            Vào làm ngay
        </a>
    </p>

    <p>Chúc bạn một ngày làm việc hiệu quả!</p>
</body>

</html>
<?php /**PATH C:\Users\kai\Desktop\php_sub\task-list\resources\views/emails/reminder.blade.php ENDPATH**/ ?>