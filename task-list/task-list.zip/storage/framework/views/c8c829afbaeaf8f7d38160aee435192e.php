<?php $__env->startSection('content'); ?>
    
    <div class="max-w-2xl mx-auto mt-6 p-4">

        
        <div class="flex justify-end items-center gap-4 mb-8 pb-4 border-b border-slate-200">
            <?php if(auth()->guard()->check()): ?>
                <span class="text-sm text-slate-600">
                    Xin chào, <span class="font-bold text-slate-800"><?php echo e(Auth::user()->name); ?></span>
                </span>

                
                <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                        class="text-sm font-medium text-red-500 hover:text-red-700 hover:underline transition-colors">
                        Đăng xuất
                    </button>
                </form>
            <?php endif; ?>
        </div>

        
        <div class="mb-6 flex justify-between items-center">
            <h1 class="text-2xl font-bold text-slate-700">📌 Việc cần làm</h1>

            <a href="<?php echo e(route('task.create')); ?>"
                class="flex items-center gap-1 text-sm font-medium text-blue-600 hover:text-blue-800 underline decoration-2 underline-offset-2 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2"
                    stroke="currentColor" class="size-4">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                </svg>
                Thêm Task
            </a>
        </div>

        
        <div class="space-y-3">
            <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                
                <div
                    class="bg-white rounded-lg border border-slate-200 shadow-sm hover:shadow-md hover:border-blue-200 transition duration-200 group">

                    
                    <a href="<?php echo e(route('task.show', ['task' => $task])); ?>" class="block px-5 py-4">
                        <div class="flex justify-between items-center">

                            
                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'font-medium text-lg transition-colors',
                                'line-through text-slate-400' => $task->completed,
                                'text-slate-700 group-hover:text-blue-600' => !$task->completed,
                            ]); ?>">
                                <?php echo e($task->title); ?>

                            </span>

                            
                            <?php if($task->completed): ?>
                                <span
                                    class="text-xs font-bold text-green-600 bg-green-100 px-2 py-1 rounded-full">XONG</span>
                            <?php else: ?>
                                <span class="text-slate-300 group-hover:text-blue-400 transition">👉</span>
                            <?php endif; ?>
                        </div>
                    </a>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                
                <div class="text-center py-10 px-4 bg-slate-50 border-2 border-dashed border-slate-300 rounded-lg">
                    <div class="text-4xl mb-2">📭</div>
                    <p class="text-slate-500 font-medium">Danh sách đang trống!</p>
                    <p class="text-slate-400 text-sm mt-1">Bạn chưa có nhiệm vụ nào, hãy tạo mới nhé.</p>
                </div>
            <?php endif; ?>
        </div>

        
        <?php if($tasks->count()): ?>
            <div class="mt-8 mb-10">
                <?php echo e($tasks->links()); ?>

            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\kai\Desktop\php_sub\task-list\resources\views/index.blade.php ENDPATH**/ ?>